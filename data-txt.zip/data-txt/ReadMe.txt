The instances are classified into 9 groups. Each group has 20 instances, named from 'instance_1' to 'instance_20'. In each txt, it first gives the name of the variable, and then the value of it. For example, 'Length of the object: 500'.

If you have any question about the data, please connect with 'baixue@chd.edu.cn'. 
